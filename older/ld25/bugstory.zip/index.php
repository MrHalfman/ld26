<!DOCTYPE html><html>
	<head>
		<meta charset="utf-8" /><!--[if IE ]><meta http-equiv="Content-Type" content="text/html;charset=UTF-8" xml:lang="fr" lang="fr"/><![endif]-->
		<title>Bug Story</title>
		<link rel="stylesheet" type="text/css" href="style/reset.css"></link>
		<link rel="stylesheet" type="text/css" href="style/main.css"></link>
		<link href="favicon.ico" type="image/x-icon" rel="SHORTCUT ICON">
</head>

	<body class="loading" style="background:black;">
	<div id="game" >
		<canvas id="cvs" width="500" height="500">
			<div id="pfs">
				<!--#######################################################-->
			</div>
		</canvas>
		<div id="txtwrapper">
			<ul id="txt"></ul>
		</div>
		<img id="end" src="end.png" style="display:none;position:absolute;" />
	</div>

	
	<script src="jquery.js"></script>
	<script>
		function log(t){
			var log=document.getElementById('txt');
			var li=document.createElement('li');
			li.innerHTML=t;
			log.appendChild(li);
			log.style.bottom=(log.style.bottom=="1px"?"0px":"1px");
			setTimeout(function(){var log=document.getElementById('txt');log.style.bottom=(log.style.bottom=="1px"?"0px":"1px");},10);
			setTimeout(function(){var log=document.getElementById('txt');log.style.bottom=(log.style.bottom=="1px"?"0px":"1px");},25);
			//log.style.bottom="0";
		}
		var story = [];
		var readingStory = false ;
		function addStory(txt,time,cb){
			story.push({txt:txt,time:time,cb:cb});
			readStory();
		};
		function readStory(){
			if(story.length && !readingStory){
				setTimeout(function(){
					log(story[0].txt);
					if(story[0].cb){story[0].cb()} ;
					story.shift();
					readingStory = false ;
					readStory();
				},story[0].time);
				readingStory = true ;
			}
		}

		function loadScript(){
			log('Computer : Loading some stuff :');
			log('Adding a cool JS lib : <strong>Momentum.JS</strong>.');
			$.get('animator.js',function(rep){
				$('<scripts>'+rep+'</scripts>').appendTo('head');
			}).success(
				function(){
					//log('Done');
					log('Loading an extra game : <strong>Bug Story</strong>.');
					$.get('game.js',function(rep){
						$('<scripts>'+rep+'</scripts>').appendTo('head');
					}).success(
						function(){//log('Done');
					}
					).error(
						function(){log('Something is broken :\'(.');}
					);
				}
			).error(
				function(){log('Something is broken :\'(.');}
			);
		}
		loadScript();

	</script>
	
	<!--<script src="animator.js"></script>
	<script src="game.js"></script>-->

	</body>
</html>